from queries.nose_plugin import Queries

__all__ = ['Queries']
